<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pendaftaran extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Pendaftaran_model');
        $this->load->helper('form');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $data['title'] = 'Pendaftaran Mudik Gratis';
		$this-> load-> view('tamplate/header', $data);
        $this->load->view('pendaftaran', $data);
        $this-> load-> view('tamplate/footer');
    }

	public function submit()
	{
		$this->form_validation->set_rules('nama', 'Nama', 'required');
		$this->form_validation->set_rules('email', 'Email', 'required|valid_email');
		$this->form_validation->set_rules('telepon', 'Telepon', 'required');
		$this->form_validation->set_rules('jumlah_penumpang', 'Jumlah Penumpang', 'required|numeric');
		$this->form_validation->set_rules('rute', 'Rute', 'required');
	
		if ($this->form_validation->run() == FALSE) {
			$this->index();
		} else {
			$bookingCode = $this->Pendaftaran_model->submitForm();
			redirect('pendaftaran/confirm/'.$bookingCode);
		}
	}
	

    public function confirm($bookingCode)
    {
        $data['bookingCode'] = $bookingCode;
        $data['title'] = 'Konfirmasi Pendaftaran';
        $this->load->view('konfirmasi', $data);
    }

}
