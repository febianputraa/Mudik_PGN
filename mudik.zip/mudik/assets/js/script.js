// Script.js

// Function to submit the registration form
function submitForm() {
    // Show loading spinner
    showLoader();

    // Get form data
    var formData = {
        name: document.getElementById('name').value,
        email: document.getElementById('email').value,
        phone: document.getElementById('phone').value
    };

    // Send form data to the server using AJAX
    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'process.php', true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4 && xhr.status === 200) {
            // Hide loading spinner
            hideLoader();

            // Process the response from the server
            var response = JSON.parse(xhr.responseText);
            if (response.success) {
                // Registration successful
                showSuccessMessage(response.message);
            } else {
                // Registration failed
                showErrorMessage(response.message);
            }
        }
    };
    xhr.send(JSON.stringify(formData));
}

// Function to show the loading spinner
function showLoader() {
    var loader = document.getElementById('loader');
    loader.style.display = 'block';
}

// Function to hide the loading spinner
function hideLoader() {
    var loader = document.getElementById('loader');
    loader.style.display = 'none';
}

// Function to show success message
function showSuccessMessage(message) {
    var successMessage = document.getElementById('success-message');
    successMessage.innerHTML = message;
    successMessage.style.display = 'block';
}

// Function to show error message
function showErrorMessage(message) {
    var errorMessage = document.getElementById('error-message');
    errorMessage.innerHTML = message;
    errorMessage.style.display = 'block';
}
