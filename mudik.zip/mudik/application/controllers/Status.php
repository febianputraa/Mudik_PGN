<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Status extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Pendaftaranmodel');
	}

	public function index()
	{
		$data['title'] = 'Cek Status Pendaftaran';
		$this->load->view('status', $data);
	}

	public function check($bookingCode)
	{
		$data['bookingCode'] = $bookingCode;
		$data['title'] = 'Status Pendaftaran';
		$data['status'] = $this->Pendaftaranmodel->getStatus($bookingCode);
		$this->load->view('status', $data);
	}

}
