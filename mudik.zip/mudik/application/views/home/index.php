<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="#">Pendaftaran Mudik Gratis</a>
        </div>
    </nav>

    <div class="container mt-5">
        <div class="row">
            <div class="col-md-6 mx-auto">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Formulir Pendaftaran</h5>
                        <?= form_open('pendaftaran/submit', ['class' => 'needs-validation', 'novalidate']) ?>
                            <div class="form-group">
                                <label for="nama">Nama</label>
                                <input type="text" name="nama" id="nama" class="form-control" required>
                                <div class="invalid-feedback">Silakan masukkan nama.</div>
                            </div>
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="email" name="email" id="email" class="form-control" required>
                                <div class="invalid-feedback">Silakan masukkan email yang valid.</div>
                            </div>
                            <div class="form-group">
                                <label for="telepon">Telepon</label>
                                <input type="tel" name="telepon" id="telepon" class="form-control" required>
                                <div class="invalid-feedback">Silakan masukkan nomor telepon.</div>
                            </div>
                            <div class="form-group">
                                <label for="jumlah_penumpang">Jumlah Penumpang</label>
                                <input type="number" name="jumlah_penumpang" id="jumlah_penumpang" class="form-control" required>
                                <div class="invalid-feedback">Silakan masukkan jumlah penumpang.</div>
                            </div>
                            <div class="form-group">
                                <label for="rute">Rute</label>
                                <select name="rute" id="rute" class="form-control" required>
                                    <option value="">Pilih rute</option>
                                    <option value="1">Rute 1</option>
                                    <option value="2">Rute 2</option>
                                    <option value="3">Rute 3</option>
                                </select>
                                <div class="invalid-feedback">Silakan pilih rute.</div>
                            </div>
                            <button type="submit" class="btn btn-primary">Daftar</button>
                        <?= form_close() ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
