<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Pendaftaran_model');
	}

	public function index()
	{
		$data['routes'] = $this->Pendaftaran_model->getRoutes();
		$data['title'] = 'Admin Dashboard';
		$this->load->view('admin', $data);
	}

	public function verify($bookingCode)
	{
		$this->Pendaftaran_model->verifyTicket($bookingCode);
		redirect('admin');
	}

}
