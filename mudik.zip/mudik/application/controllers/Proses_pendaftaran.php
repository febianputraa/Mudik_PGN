<?php
// controllers/proses_pendaftaran.php

class Proses_pendaftaran extends CI_Controller {
  
    public function __construct() {
        parent::__construct();
        // Load model yang dibutuhkan
        $this->load->model('Pendaftaran_model');
    }
  
    public function index() {
        // Ambil data yang dikirimkan melalui formulir
        $nama = $this->input->post('nama');
        $email = $this->input->post('email');
        $jumlah_penumpang = $this->input->post('jumlah_penumpang');
        $rute = $this->input->post('rute');

        // Lakukan validasi data (misalnya, pastikan semua field terisi)
        // Jika data valid, simpan data ke dalam database dan berikan kode booking
        // Jika data tidak valid, tampilkan pesan kesalahan

        // Tampilkan halaman konfirmasi dengan informasi dan kode booking
        $data['nama'] = $nama;
        $data['kode_booking'] = '[kode_booking]';
        $this->load->view('konfirmasi', $data);
    }
  
}
