<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pendaftaran_model extends CI_Model {

    public function submitForm($data)
    {
        $this->db->insert('pendaftaran', $data);
        return $this->db->insert_id();
    }

    public function getPendaftaranByBookingCode($bookingCode)
    {
        $this->db->where('booking_code', $bookingCode);
        return $this->db->get('pendaftaran')->row();
    }

    public function updateStatus($bookingCode, $status)
    {
        $this->db->set('status', $status);
        $this->db->where('booking_code', $bookingCode);
        $this->db->update('pendaftaran');
    }

    public function getJumlahPenumpangByRute($ruteId)
    {
        $this->db->where('rute_id', $ruteId);
        return $this->db->count_all_results('pendaftaran');
    }

}
