<!DOCTYPE html>
<html>
<head>
    <title>Status Pendaftaran - Aplikasi Mudik Gratis</title>
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/style.css'); ?>">
</head>
<body>
    <h1>Status Pendaftaran</h1>
    <div class="container">
        <?php foreach ($status as $row): ?>
            <h2>Pendaftaran dengan Kode Booking: <?php echo $row->booking_code; ?></h2>
            <p>Status Verifikasi: <?php echo $row->status_verifikasi; ?></p>
            <?php if ($row->status_verifikasi === 'Verified'): ?>
                <p>Tiket: <?php echo $row->tiket; ?></p>
            <?php endif; ?>
        <?php endforeach; ?>
    </div>
</body>
</html>
