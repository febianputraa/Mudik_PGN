<!DOCTYPE html>
<html>
<head>
    <title>Pendaftaran - Aplikasi Mudik Gratis</title>
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/style.css'); ?>">
</head>
<body>
    <h1>Pendaftaran</h1>
    <form action="<?php echo base_url('pendaftaran/submit'); ?>" method="post">
        <div class="form-group">
            <label for="nama">Nama:</label>
            <input type="text" name="nama" id="nama" required>
        </div>
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" name="email" id="email" required>
        </div>
        <div class="form-group">
            <label for="telepon">Telepon:</label>
            <input type="text" name="telepon" id="telepon" required>
        </div>
        <div class="form-group">
            <label for="jumlah_penumpang">Jumlah Penumpang:</label>
            <input type="number" name="jumlah_penumpang" id="jumlah_penumpang" min="1" required>
        </div>
        <div class="form-group">
            <label for="rute">Rute:</label>
            <select name="rute" id="rute" required>
                <option value="Jakarta - Surabaya">Jakarta - Surabaya</option>
                <option value="Jakarta - Bandung">Jakarta - Bandung</option>
                <option value="Jakarta - Yogyakarta">Jakarta - Yogyakarta</option>
            </select>
        </div>
        <input type="submit" value="Submit">
    </form>
</body>
</html>
