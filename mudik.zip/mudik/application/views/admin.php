<!DOCTYPE html>
<html>
<head>
    <title>Admin Panel - Aplikasi Mudik Gratis</title>
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/style.css'); ?>">
</head>
<body>
    <h1>Admin Panel</h1>
    <h2>Data Moda Transportasi</h2>
    <table>
        <tr>
            <th>Moda Transportasi</th>
            <th>Rute</th>
            <th>Jadwal Keberangkatan</th>
            <th>Slot Tersedia</th>
        </tr>
        <?php foreach ($routes as $route): ?>
        <tr>
            <td><?php echo $route->moda_transportasi; ?></td>
            <td><?php echo $route->rute; ?></td>
            <td><?php echo $route->jadwal_keberangkatan; ?></td>
            <td><?php echo $route->slot_tersedia; ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
    <h2>Data Pendaftaran</h2>
    <table>
        <tr>
            <th>Nama</th>
            <th>Email</th>
            <th>Telepon</th>
            <th>Jumlah Penumpang</th>
            <th>Rute</th>
            <th>Status Verifikasi</th>
            <th>Tiket</th>
        </tr>
        <?php foreach ($registrations as $registration): ?>
        <tr>
            <td><?php echo $registration->nama; ?></td>
            <td><?php echo $registration->email; ?></td>
            <td><?php echo $registration->telepon; ?></td>
            <td><?php echo $registration->jumlah_penumpang; ?></td>
            <td><?php echo $registration->rute; ?></td>
            <td><?php echo $registration->status_verifikasi; ?></td>
            <td><?php echo $registration->tiket; ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
