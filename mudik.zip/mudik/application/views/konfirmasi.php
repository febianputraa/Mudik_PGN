<!DOCTYPE html>
<html>
<head>
    <title>Konfirmasi Pendaftaran - Aplikasi Mudik Gratis</title>
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/style.css'); ?>">
</head>
<body>
    <h1>Konfirmasi Pendaftaran</h1>
    <div class="container">
        <?php if ($status->status_verifikasi === 'Verified'): ?>
            <h2>Pendaftaran dengan Kode Booking: <?php echo $status->booking_code; ?></h2>
            <p>Status Verifikasi: <?php echo $status->status_verifikasi; ?></p>
            <p>Tiket: <?php echo $status->tiket; ?></p>
        <?php else: ?>
            <h2>Pendaftaran dengan Kode Booking: <?php echo $status->booking_code; ?></h2>
            <p>Status Verifikasi: <?php echo $status->status_verifikasi; ?></p>
            <p>Tiket: Belum Terverifikasi</p>
        <?php endif; ?>
    </div>
</body>
</html>
